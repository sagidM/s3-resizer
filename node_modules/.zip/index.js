'use strict';

const AWS = require('aws-sdk')
const S3 = new AWS.S3({
  signatureVersion: 'v4',
});
const Sharp = require('sharp');

function objectInfo(obj){
    var res = []
    for (var key in obj){
        res.push(key + ": " + obj[key]);
    }
    return res.join("\n\n")
    return res.length
}

exports.handler = (event, context, callback) => {
    var obj = S3.getObject({Bucket: 'tttt331', Key: '1846481208.jpg'}).promise();
    console.log("-----start-------")
    console.log(obj)
    console.log("-----end-------")
    obj.then(data =>
        callback(null, {
            statusCode: 200,
            body: typeof (data),
            headers: {
                "Location" : "http://ryangreen.ca",
                "content-type": "text/plain"
            }
        })
    );
};

